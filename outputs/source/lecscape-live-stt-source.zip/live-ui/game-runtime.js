// 게임 팀 통합 지점입니다. 이 파일의 mountGame 구현만 교체하면
// STT/개념 분석 화면과 데이터 전달 코드는 수정할 필요가 없습니다.
export async function mountGame(root, gameInput, context = {}) {
  const room = gameInput.roomBlueprint.room;
  root.replaceChildren();

  const section = document.createElement("section");
  section.className = "game-preview";
  const eyebrow = document.createElement("p");
  eyebrow.className = "eyebrow";
  eyebrow.textContent = "GAME MODULE HANDOFF READY";
  const title = document.createElement("h1");
  title.textContent = room.title;
  const story = document.createElement("p");
  story.className = "game-story";
  story.textContent = room.story;
  const notice = document.createElement("p");
  notice.className = "integration-notice";
  notice.textContent = "강의 분석 데이터 전달이 완료되었습니다. 게임 팀은 game-runtime.js의 mountGame(root, gameInput, context)만 교체하면 됩니다.";
  const stages = document.createElement("ol");
  stages.className = "stage-list";
  for (const stage of room.stages) {
    const item = document.createElement("li");
    const stageTitle = document.createElement("strong");
    stageTitle.textContent = stage.title;
    const goal = document.createElement("span");
    goal.textContent = stage.goal;
    item.append(stageTitle, goal);
    stages.append(item);
  }
  const meta = document.createElement("p");
  meta.className = "analysis-path";
  meta.textContent = `session: ${context.sessionId} · concepts: ${gameInput.coreConcepts.length}`;
  section.append(eyebrow, title, story, notice, stages, meta);
  root.append(section);
}
