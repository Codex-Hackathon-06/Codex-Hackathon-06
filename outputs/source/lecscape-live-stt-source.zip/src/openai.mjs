import { readFile } from "node:fs/promises";
import { basename, extname } from "node:path";

function contentTypeFor(path) {
  const extension = extname(path).toLowerCase();
  if (extension === ".mp3") return "audio/mpeg";
  if (extension === ".m4a") return "audio/mp4";
  if (extension === ".wav") return "audio/wav";
  return "application/octet-stream";
}

export async function createWhisperTranscription(options) {
  const apiKey = options.apiKey ?? process.env.OPENAI_API_KEY;
  if (!apiKey) {
    const error = new Error(
      "OPENAI_API_KEY is not set. Export it in your shell, then rerun the command.",
    );
    error.code = "OPENAI_API_KEY_MISSING";
    throw error;
  }

  const audio = await readFile(options.audioPath);
  const form = new FormData();
  form.append(
    "file",
    new Blob([audio], { type: contentTypeFor(options.audioPath) }),
    basename(options.audioPath),
  );
  form.append("model", "whisper-1");
  form.append("language", "ko");
  form.append("response_format", "verbose_json");
  form.append("timestamp_granularities[]", "segment");
  if (options.prompt?.trim()) form.append("prompt", options.prompt.trim());

  const fetchImpl = options.fetchImpl ?? fetch;
  const response = await fetchImpl("https://api.openai.com/v1/audio/transcriptions", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}` },
    body: form,
    signal: options.signal ?? AbortSignal.timeout(20 * 60 * 1000),
  });
  if (!response.ok) {
    const body = await response.text();
    throw new Error(`OpenAI transcription failed (${response.status}): ${body}`);
  }
  const raw = await response.json();
  if (!Array.isArray(raw.segments)) {
    throw new Error("OpenAI transcription response did not include timestamped segments");
  }
  return raw;
}

